-- ============================================================
-- 마이그레이션: "임대차 계약 관리" 탭 추가
-- 이미 배포되어 운영 중인 D1 데이터베이스에 lease_contracts 표만 추가합니다.
-- 기존 sites/records/journal_entries/accounting_journal/followups/site_accounts/
-- work_memos/site_schedules/site_rules 표는 전혀 건드리지 않으므로 기존 데이터는 안전합니다.
--
-- ※ 계약서 파일(부동산임대차계약서)의 실물은 "관리규약" 탭에서 이미 쓰고 있는
--   같은 R2 버킷(RULES_BUCKET / bms-money-site-rules)에 저장됩니다. 저장 경로만
--   lease-contracts/... 로 달라서 관리규약 파일과 섞이지 않습니다.
--   → R2 버킷을 새로 만들 필요도, wrangler.toml을 고칠 필요도 없습니다.
--
-- 실행 방법 (Cloudflare 대시보드 D1 Console에 아래 내용 전체를 붙여넣고 Execute):
--   또는 npx wrangler d1 execute bms-money-db --remote --file=./migration_lease_contracts.sql
--
-- 표 생성은 IF NOT EXISTS라 몇 번을 실행해도 안전합니다(idempotent).
-- ============================================================

CREATE TABLE IF NOT EXISTS lease_contracts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  site_name TEXT NOT NULL,                  -- 현장명
  start_date TEXT,                          -- 계약 시작일 YYYY-MM-DD
  end_date TEXT,                            -- 계약 종료일(만기일) YYYY-MM-DD
  tenant_name TEXT DEFAULT '',              -- 임차인
  tenant_contact TEXT DEFAULT '',           -- 임차인 연락처
  deposit INTEGER NOT NULL DEFAULT 0,       -- 보증금(원)
  monthly_rent INTEGER NOT NULL DEFAULT 0,  -- 월세(원)
  fee_type TEXT DEFAULT '',                 -- 관리비 방식: '정액제' | '정산제' | '' (미선택)
  fee_amount INTEGER NOT NULL DEFAULT 0,    -- 관리비 금액(원) — 정산제면 0으로 비워둬도 됩니다
  remarks TEXT DEFAULT '',                  -- 비고
  filename TEXT DEFAULT '',                 -- 업로드된 계약서 원본 파일명
  r2_key TEXT DEFAULT '',                   -- R2에 저장된 실제 경로(계약 건마다 1개, 재업로드 시 덮어씀)
  uploaded_at TEXT,                         -- 계약서 업로드 시각
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_lease_contracts_site ON lease_contracts(site_name);
CREATE INDEX IF NOT EXISTS idx_lease_contracts_end ON lease_contracts(end_date);
